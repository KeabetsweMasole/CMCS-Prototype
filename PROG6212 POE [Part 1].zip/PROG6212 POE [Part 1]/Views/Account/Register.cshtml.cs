using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace one_part_naledi.Views.Account
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
