using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace one_part_naledi.Views.Account
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
