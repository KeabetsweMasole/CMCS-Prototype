using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace one_part_naledi.Views.Home
{
    public class ClaimModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
