using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace one_part_naledi.Views.Home
{
    public class TrackModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
