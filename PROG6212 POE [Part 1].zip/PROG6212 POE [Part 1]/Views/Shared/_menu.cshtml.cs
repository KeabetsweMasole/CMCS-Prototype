using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace one_part_naledi.Views.Shared
{
    public class _menuModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
