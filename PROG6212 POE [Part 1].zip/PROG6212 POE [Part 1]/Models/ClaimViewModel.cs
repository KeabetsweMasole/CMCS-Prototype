﻿using System;

namespace YourApp.Models
{
    public class ClaimViewModel
    {
        public int ClaimId { get; set; }
        public string UserId { get; set; }
        public string ModuleId { get; set; }
        public int Sessions { get; set; }
        public int Hours { get; set; }
        public decimal Rate { get; set; }
        public decimal TotalAmount { get; set; }
        public string Status { get; set; }
        public DateTime SubmittedDate { get; set; }
        public string DocumentPath { get; set; }
    }
}
