﻿using Microsoft.AspNetCore.Mvc;
using YourApp.Models;
using Microsoft.AspNetCore.Http;

namespace YourApp.Controllers
{
    public class AccountController : Controller
    {
        // GET: /Account/Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: /Account/Register
        [HttpPost]
        public IActionResult Register(UserViewModel model)
        {
            if (ModelState.IsValid)
            {
                // TODO: Save to database instead of TempData
                TempData["RegisteredUser"] = model.Username;
                TempData["RegisteredPass"] = model.Password;

                return RedirectToAction("Login");
            }
            return View(model);
        }

        // GET: /Account/Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: /Account/Login
        [HttpPost]
        public IActionResult Login(UserViewModel model)
        {
            var user = TempData["RegisteredUser"] as string;
            var pass = TempData["RegisteredPass"] as string;

            // Simple check (replace with DB authentication)
            if (model.Username == user && model.Password == pass)
            {
                HttpContext.Session.SetString("User", model.Username);
                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError("", "Invalid username or password.");
            return View(model);
        }

        // GET: /Account/Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("User");
            return RedirectToAction("Login");
        }
    }
}
