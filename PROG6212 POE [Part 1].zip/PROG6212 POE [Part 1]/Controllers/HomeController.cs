using Microsoft.AspNetCore.Mvc;
using YourApp.Models;
using System;
using System.Collections.Generic;

namespace YourApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Claim()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SubmitClaim(ClaimViewModel claim)
        {
            // TODO: Save to database
            claim.ClaimId = new Random().Next(1000, 9999);
            claim.Status = "Submitted";
            claim.SubmittedDate = DateTime.Now;

            // For now, just redirect back to Track page
            return RedirectToAction("Track");
        }

        public IActionResult Track()
        {
            // Fake data (replace with database query later)
            var claims = new List<ClaimViewModel>
            {
                new ClaimViewModel
                {
                    ClaimId = 1,
                    UserId = "101",
                    ModuleId = "501",
                    Sessions = 10,
                    Hours = 15,
                    Rate = 150,
                    TotalAmount = 2250,
                    Status = "Pre-approved",
                    SubmittedDate = DateTime.Now.AddDays(-3),
                    DocumentPath = "/documents/claim1.pdf"
                },
                new ClaimViewModel
                {
                    ClaimId = 2,
                    UserId = "102",
                    ModuleId = "502",
                    Sessions = 5,
                    Hours = 8,
                    Rate = 200,
                    TotalAmount = 1600,
                    Status = "Pending",
                    SubmittedDate = DateTime.Now.AddDays(-1),
                    DocumentPath = "/documents/claim2.pdf"
                }
            };

            return View(claims);
        }
    }
}
